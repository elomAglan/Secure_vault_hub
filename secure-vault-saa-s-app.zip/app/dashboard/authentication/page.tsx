'use client'

import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { useState } from 'react'
import { mockAuthSettings } from '@/lib/mock-data'
import { Mail, Github, Google, Wand2, Lock } from 'lucide-react'

export default function AuthenticationPage() {
  const [settings, setSettings] = useState(mockAuthSettings)

  const authMethods = [
    {
      name: 'Email & Password',
      description: 'Allow users to sign up and log in with email and password',
      key: 'emailPassword',
      icon: Mail,
    },
    {
      name: 'Google OAuth',
      description: 'Let users sign in using their Google account',
      key: 'googleOAuth' as const,
      icon: Google,
    },
    {
      name: 'GitHub OAuth',
      description: 'Let users sign in using their GitHub account',
      key: 'githubOAuth' as const,
      icon: Github,
    },
    {
      name: 'Magic Links',
      description: 'Send passwordless magic links via email',
      key: 'magicLinks' as const,
      icon: Wand2,
    },
    {
      name: 'Two-Factor Authentication',
      description: 'Require a second factor to verify identity',
      key: 'twoFactor' as const,
      icon: Lock,
    },
  ]

  const toggleSetting = (key: keyof typeof mockAuthSettings) => {
    setSettings({
      ...settings,
      [key]: !settings[key],
    })
  }

  return (
    <div className="max-w-3xl space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Authentication Settings</h1>
        <p className="mt-2 text-foreground/60">
          Configure which authentication methods are available for your application
        </p>
      </div>

      {/* Auth Methods */}
      <div className="space-y-4">
        {authMethods.map((method) => {
          const Icon = method.icon
          const isEnabled = settings[method.key]

          return (
            <Card key={method.key} className="border border-border p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <Icon className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold">{method.name}</h3>
                    <p className="text-sm text-foreground/60 mt-1">
                      {method.description}
                    </p>
                    <div className="mt-2">
                      {isEnabled ? (
                        <Badge>Enabled</Badge>
                      ) : (
                        <Badge variant="secondary">Disabled</Badge>
                      )}
                    </div>
                  </div>
                </div>
                <Switch
                  checked={isEnabled}
                  onCheckedChange={() => toggleSetting(method.key)}
                />
              </div>
            </Card>
          )
        })}
      </div>

      {/* Security Options */}
      <Card className="border border-border p-6">
        <h2 className="mb-6 text-xl font-semibold">Security Options</h2>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">Require Email Verification</h3>
              <p className="text-sm text-foreground/60 mt-1">
                Verify email addresses before users can log in
              </p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">Password Requirements</h3>
              <p className="text-sm text-foreground/60 mt-1">
                Enforce strong password policies
              </p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">Account Lockout</h3>
              <p className="text-sm text-foreground/60 mt-1">
                Lock accounts after failed login attempts
              </p>
            </div>
            <Switch defaultChecked />
          </div>
        </div>
      </Card>

      {/* Session Management */}
      <Card className="border border-border p-6">
        <h2 className="mb-6 text-xl font-semibold">Session Management</h2>

        <div className="space-y-6">
          <div>
            <Label className="block text-sm font-medium mb-2">Session Duration</Label>
            <select className="w-full px-3 py-2 border border-border rounded-md bg-background">
              <option>30 minutes</option>
              <option selected>1 hour</option>
              <option>2 hours</option>
              <option>24 hours</option>
            </select>
          </div>

          <div>
            <Label className="block text-sm font-medium mb-2">Refresh Token Expiration</Label>
            <select className="w-full px-3 py-2 border border-border rounded-md bg-background">
              <option>7 days</option>
              <option selected>30 days</option>
              <option>90 days</option>
              <option>Never expire</option>
            </select>
          </div>
        </div>
      </Card>

      <Button>Save Changes</Button>
    </div>
  )
}
